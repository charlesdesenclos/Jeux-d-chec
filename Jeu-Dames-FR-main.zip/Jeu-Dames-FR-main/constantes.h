#pragma once
#ifndef DEF_CONSTANTES
#define DEF_CONSTANTES

extern float delai;

#endif // DEF_CONSTANTES
